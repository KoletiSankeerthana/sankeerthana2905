#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/* Define constants */
#define Q_size 5

/* Define a structure for the queue */
typedef struct {
    int front; // Index of the front element
    int rear; // Index of the last element
    int size; // Current size of the queue
    int data[Q_size]; // Array for queue elements
} Q;

/* Function Prototypes */
void ENQUEUE(Q* q, int x);
int DEQUEUE(Q* q);
void PUSH(Q* q1, Q* q2, int x);
int POP(Q* q1, Q* q2);
bool isQ_EMPTY(Q* q);
bool isQ_FULL(Q* q);
void displayStack(Q* q);

int main(void) {
    Q q1 = { .front = -1, .rear = -1, .size = 0 }; // Queue to enqueue elements
    Q q2 = { .front = -1, .rear = -1, .size = 0 }; // Auxiliary queue

    int x = 0;
    char option = '\0';

    printf("-----------------\n");
    printf("---STACK  Menu---\n");
    printf("Show: S\n");
    printf("PUSH: I\n");
    printf("POP : D\n");
    printf("EXIT: E\n");
    printf("-----------------\n");

    while (1) {
        printf("Enter your option: ");
        scanf(" %c", &option);

        switch (option) {
            case 'S':
                printf("Displaying Stack\n\n");
                displayStack(&q2);
                break;

            case 'I':
                printf("Enter element to insert: ");
                scanf("%d", &x);
                PUSH(&q1, &q2, x);
                break;

            case 'D':
                x = POP(&q1, &q2);
                if (x != -1) {
                    printf("Popped element: %d\n", x);
                }
                break;

            case 'E':
                printf("Exit\n\n");
                exit(0);

            default:
                printf("Enter correct option\n\n");
        }
    }

    return 0;
}

/* Enqueue Function */
void ENQUEUE(Q* q, int x) {
    if (isQ_FULL(q)) {
        printf("Queue is full\n");
        return;
    }
    if (isQ_EMPTY(q)) {
        q->front = 0;
    }
    q->rear = (q->rear + 1) % Q_size;
    q->data[q->rear] = x;
    q->size++;
}

/* Dequeue Function */
int DEQUEUE(Q* q) {
    if (isQ_EMPTY(q)) {
        printf("The Queue is empty\n");
        return -1;
    }
    int value = q->data[q->front];
    if (q->front == q->rear) {
        q->front = -1;
        q->rear = -1;
    } else {
        q->front = (q->front + 1) % Q_size;
    }
    q->size--;
    return value;
}

/* Push Function */
void PUSH(Q* q1, Q* q2, int x) {
    ENQUEUE(q1, x); // Enqueue the element into q1

    // Move all the elements from q2 to q1
    while (!isQ_EMPTY(q2)) {
        ENQUEUE(q1, DEQUEUE(q2));
    }

    // Swap q1 and q2 to make q2 the new stack
    Q temp = *q1;
    *q1 = *q2;
    *q2 = temp;
}

/* Pop Function */
int POP(Q* q1, Q* q2) {
    return DEQUEUE(q2); // Dequeue from q2, which is maintaining stack order
}

/* Check if Queue is Empty */
bool isQ_EMPTY(Q* q) {
    return q->size == 0;
}

/* Check if Queue is Full */
bool isQ_FULL(Q* q) {
    return q->size == Q_size;
}

/* Display function */
void displayStack(Q* q) {
    if (isQ_EMPTY(q)) {
        printf("The stack is empty\n");
        return;
    }

    printf("Stack elements: ");
    for (int i = q->front, count = 0; count < q->size; count++) {
        printf("%d ", q->data[i]);
        i = (i + 1) % Q_size;
    }
    printf("\n");
}
