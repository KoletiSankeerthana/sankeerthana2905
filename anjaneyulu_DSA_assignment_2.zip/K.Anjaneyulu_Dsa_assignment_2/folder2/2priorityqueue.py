import heapq

class PriorityQueue:
    def __init__(self):
        self.queue = []
        self.index = 0

    def insert(self, priority, item):
        heapq.heappush(self.queue, (priority, self.index, item))
        self.index += 1

    def extract_min(self):
        if not self.queue:
            return None
        _, _, item = heapq.heappop(self.queue)
        return item

    def decrease_key(self, item, new_priority):
        for i in range(len(self.queue)):
            if self.queue[i][2] == item:
                priority, index, item = self.queue[i]
                if new_priority < priority:
                    self.queue[i] = (new_priority, index, item)
                    heapq.heapify(self.queue)
                break

    def is_empty(self):
        return len(self.queue) == 0


