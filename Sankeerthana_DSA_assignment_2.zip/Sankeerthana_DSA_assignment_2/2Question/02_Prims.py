from PriorityQueue import PriorityQueue

def prims_algorithm(graph):
    vertex_attributes = {v: {'key': float('inf'), 'parent': None} for v in graph} # Initialize the vertex attributes with key (infinity) and parent (None) for all vertices
    vertex_attributes[next(iter(graph))]['key'] = 0 # Set the key of the first vertex to 0

    
    priority_queue = PriorityQueue() # Create a priority queue and insert all vertices with their keys
    for vertex in graph:
        priority_queue.insert(vertex_attributes[vertex]['key'], vertex)

    while not priority_queue.is_empty(): # While the priority queue is not empty
    
        current_vertex = priority_queue.extract_min() # Extract the vertex with the minimum key value

       
        for neighbor, weight in graph[current_vertex].items():  # For each neighbor of the current vertex
            # Check if the neighbor is still in the queue and the weight is less than the current key or not
            if any(item == neighbor for _, _, item in priority_queue.queue) and weight < vertex_attributes[neighbor]['key']:
                
                vertex_attributes[neighbor]['parent'] = current_vertex # Update the parent and key of the neighbor
                vertex_attributes[neighbor]['key'] = weight
                priority_queue.decrease_key(neighbor, weight) # Decrease the key value in the priority queue

    # Collect the minimum spanning tree edges
    mst = []
    for vertex, attr in vertex_attributes.items():
        if attr['parent'] is not None:
            mst.append((attr['parent'], vertex, attr['key']))

    return mst

# Example graph representation
graph = {
    'K': {'L': 2, 'N': 3},
    'L': {'K': 2, 'N': 1, 'M': 1},
    'M': {'L': 1, 'N': 1, 'O': 4},
    'N': {'K': 3, 'L': 1, 'M': 1, 'O': 2},
    'O': {'N': 2, 'M': 4}
}

# Prim's algorithm to find the minimum spanning tree
minimum_spanning_tree = prims_algorithm(graph)

print("Minimum Spanning Tree Edges:")
for edge in minimum_spanning_tree:
    print(edge)
