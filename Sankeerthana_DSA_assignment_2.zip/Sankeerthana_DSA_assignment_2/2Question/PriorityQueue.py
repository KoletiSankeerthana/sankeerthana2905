import heapq

class PriorityQueue:
    def __init__(self): # Initialize an empty list to store the elements of the priority queue
        
        self.queue = [] # Initialize an index to maintain the order of insertion
        
        self.index = 0

    def insert(self, priority, item):  # Insert the (priority, index, item) tuple into the heap
       
        heapq.heappush(self.queue, (priority, self.index, item))  # Increment the index to ensure the correct order of insertion
       
        self.index += 1

    def extract_min(self):  # Return None if the queue is empty
       
        if not self.queue:
            return None # Pop the (priority, index, item) tuple with the smallest priority from the heap
        
        _, _, item = heapq.heappop(self.queue)
        return item

    def decrease_key(self, item, new_priority): # to find the item Iterate over the queue 
        
        for i in range(len(self.queue)):
            if self.queue[i][2] == item:
                priority, index, item = self.queue[i] # update the priority,If the new priority is smaller,
                
                if new_priority < priority:
                    self.queue[i] = (new_priority, index, item) # Reorder the heap to maintain the heap property
                    
                    heapq.heapify(self.queue)
                break

    def is_empty(self): # if queue is empty return true,orelse false
        
        return len(self.queue) == 0
